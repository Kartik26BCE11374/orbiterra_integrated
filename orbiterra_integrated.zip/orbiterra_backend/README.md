# ORBITERRA Backend

This is the original FastAPI backend folder. It retains `main.py`, `static/`,
`requirements.txt`, `.env.example`, and the original API implementation.

The complete combined ORBITERRA + ASTRA run instructions are in the repository
root `README.md`. Start the full stack from that root with:

```bash
docker compose up --build
```

For a local Python-only API run, install `requirements.txt` and run
`uvicorn main:app --reload` from this directory. Set `ORBITERRA_MQTT_ENABLED=false`
if the TLS MQTT broker is not running locally.

# Run this after starting the API in another terminal.
$base = "http://127.0.0.1:8000"
Invoke-RestMethod "$base/api/health"
Invoke-RestMethod "$base/api/dashboard"
Invoke-RestMethod -Method Post -Uri "$base/api/irrigation/start" -ContentType "application/json" -Body '{"duration_minutes":1}'
Start-Sleep -Seconds 2
Invoke-RestMethod -Method Post -Uri "$base/api/irrigation/stop" -ContentType "application/json" -Body '{}'
Invoke-RestMethod "$base/api/irrigation/history"

import asyncio
import os
import sqlite3
import time
import json
import hmac
import hashlib
import logging
from contextlib import asynccontextmanager
from datetime import datetime, date, timezone
from pathlib import Path
from typing import Optional

import httpx
import paho.mqtt.client as mqtt
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.getenv("ORBITERRA_DB", ROOT / "orbiterra.db"))
SENSOR_API_KEY = os.getenv("ORBITERRA_SENSOR_API_KEY", "change-this-sensor-key")
HARDWARE_ENABLED = os.getenv("ORBITERRA_HARDWARE_ENABLED", "false").lower() == "true"
RELAY_BRIDGE_URL = os.getenv("ORBITERRA_RELAY_BRIDGE_URL", "")
RELAY_BRIDGE_TOKEN = os.getenv("ORBITERRA_RELAY_BRIDGE_TOKEN", "")
MAX_DAILY_MINUTES = int(os.getenv("ORBITERRA_MAX_DAILY_MINUTES", "90"))
MQTT_ENABLED = os.getenv("ORBITERRA_MQTT_ENABLED", "true").lower() == "true"
MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_PORT = int(os.getenv("MQTT_PORT", "8883"))
MQTT_CA = os.getenv("MQTT_CA", str(ROOT.parent / "astra" / "certs" / "ca.crt"))
MQTT_CERT = os.getenv("MQTT_CERT", str(ROOT.parent / "astra" / "certs" / "pump-001.crt"))
MQTT_KEY = os.getenv("MQTT_KEY", str(ROOT.parent / "astra" / "certs" / "pump-001.key"))
ASTRA_HMAC_KEY = os.getenv("ASTRA_HMAC_KEY", "development-only-change-this-key").encode()
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("orbiterra")
mqtt_client = None
mqtt_connected = False
latest_ai_recommendation = None

def mqtt_on_connect(client, userdata, flags, reason_code, properties):
    global mqtt_connected
    mqtt_connected = (reason_code == 0)
    if mqtt_connected:
        logger.info("ORBITERRA connected to MQTT over verified TLS")
        client.subscribe("devices/pump-001/commands", qos=1)
    else:
        logger.error("ORBITERRA MQTT connection failed: %s", reason_code)

def mqtt_on_disconnect(client, userdata, disconnect_flags, reason_code, properties):
    global mqtt_connected
    mqtt_connected = False

def mqtt_on_message(client, userdata, message):
    global latest_ai_recommendation
    try:
        command = json.loads(message.payload.decode("utf-8"))
        signed_fields = {key: command[key] for key in ("cmd", "duration_min", "seq", "device")}
        raw = json.dumps(signed_fields, sort_keys=True, separators=(",", ":")).encode()
        expected = hmac.new(ASTRA_HMAC_KEY, raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(str(command.get("sig", "")), expected):
            logger.warning("Rejected AI recommendation with invalid signature")
            return
        duration = float(command["duration_min"])
        sequence = int(command["seq"])
        if (command.get("cmd") != "irrigation_recommendation"
                or command.get("device") != "pump-001"
                or not 0 <= duration <= 120 or sequence < 1):
            logger.warning("Rejected AI recommendation with invalid command fields")
            return
        # Persistent monotonic sequence check prevents replay across API restarts.
        with connect() as db:
            updated = db.execute(
                "UPDATE security_state SET last_ai_seq=? WHERE id=1 AND last_ai_seq<?",
                (sequence, sequence)
            )
            if updated.rowcount != 1:
                logger.warning("Rejected stale/replayed AI recommendation sequence %s", sequence)
                return
        latest_ai_recommendation = command
        logger.info("Accepted signed ASTRA recommendation: %s", command.get("decision"))
    except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
        logger.warning("Rejected malformed MQTT command: %s", exc)

def publish_sensor_to_ai(reading):
    if not MQTT_ENABLED or mqtt_client is None or not mqtt_connected:
        return False
    payload = {
        "moisture": reading["soil_moisture"],
        "current": 3.5, "eto": 4.0,
        "rain_mm": reading.get("rainfall_mm", 0.0), "stage": "mid",
    }
    result = mqtt_client.publish("devices/pump-001/sensors", json.dumps(payload), qos=1)
    return result.rc == mqtt.MQTT_ERR_SUCCESS

def start_mqtt():
    global mqtt_client
    if not MQTT_ENABLED:
        logger.info("MQTT integration disabled by configuration")
        return
    mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="orbiterra-api-pump")
    mqtt_client.tls_set(ca_certs=MQTT_CA, certfile=MQTT_CERT, keyfile=MQTT_KEY)
    mqtt_client.tls_insecure_set(False)
    mqtt_client.on_connect = mqtt_on_connect
    mqtt_client.on_disconnect = mqtt_on_disconnect
    mqtt_client.on_message = mqtt_on_message
    mqtt_client.reconnect_delay_set(min_delay=1, max_delay=30)
    mqtt_client.connect_async(MQTT_HOST, MQTT_PORT, keepalive=60)
    mqtt_client.loop_start()

def stop_mqtt():
    global mqtt_client, mqtt_connected
    if mqtt_client is not None:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()
        mqtt_client = None
    mqtt_connected = False

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS sensor_readings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            soil_moisture REAL NOT NULL,
            air_temperature REAL,
            air_humidity REAL,
            soil_temperature REAL,
            rainfall_mm REAL DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS farm (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            farmer_name TEXT DEFAULT 'Farmer',
            village TEXT DEFAULT 'Your village',
            district TEXT DEFAULT 'Your district',
            area_acres REAL DEFAULT 2.5,
            crop TEXT DEFAULT 'Wheat',
            crop_age_days INTEGER DEFAULT 45,
            soil_type TEXT DEFAULT 'Black soil',
            terrain TEXT DEFAULT 'Flat'
        );
        CREATE TABLE IF NOT EXISTS irrigation (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            duration_minutes INTEGER NOT NULL,
            status TEXT NOT NULL,
            water_litres REAL DEFAULT 0,
            stop_reason TEXT
        );
        CREATE TABLE IF NOT EXISTS pump_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            is_on INTEGER NOT NULL DEFAULT 0,
            started_at REAL,
            end_time REAL,
            duration_minutes INTEGER DEFAULT 0,
            used_minutes_today REAL DEFAULT 0,
            usage_date TEXT
        );
        CREATE TABLE IF NOT EXISTS security_state (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            last_ai_seq INTEGER NOT NULL DEFAULT 0
        );
        INSERT OR IGNORE INTO security_state (id, last_ai_seq) VALUES (1, 0);
        INSERT OR IGNORE INTO farm (id) VALUES (1);
        INSERT OR IGNORE INTO pump_state (id, usage_date) VALUES (1, date('now'));
        """)
        count = db.execute("SELECT COUNT(*) FROM sensor_readings").fetchone()[0]
        if count == 0:
            db.execute("""INSERT INTO sensor_readings
                (soil_moisture, air_temperature, air_humidity, soil_temperature, rainfall_mm, created_at)
                VALUES (42, 28, 65, 24, 0, ?)""", (now_iso(),))

def latest_sensor():
    with connect() as db:
        row = db.execute("SELECT * FROM sensor_readings ORDER BY id DESC LIMIT 1").fetchone()
        return dict(row) if row else None

def read_pump():
    with connect() as db:
        row = db.execute("SELECT * FROM pump_state WHERE id=1").fetchone()
        return dict(row)

async def set_physical_relay(on: bool):
    """Optional bridge contract: POST {\"state\":\"ON\"|\"OFF\"} to your relay controller."""
    if not HARDWARE_ENABLED:
        return {"mode": "simulation", "command_sent": False}
    if not RELAY_BRIDGE_URL:
        raise HTTPException(503, "Hardware mode is enabled but ORBITERRA_RELAY_BRIDGE_URL is missing.")
    headers = {"Authorization": f"Bearer {RELAY_BRIDGE_TOKEN}"} if RELAY_BRIDGE_TOKEN else {}
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            response = await client.post(
                RELAY_BRIDGE_URL,
                json={"state": "ON" if on else "OFF"},
                headers=headers
            )
            response.raise_for_status()
    except Exception as exc:
        raise HTTPException(502, f"Relay bridge command failed: {exc}")
    return {"mode": "hardware", "command_sent": True}

def normalize_daily_usage(db):
    row = db.execute("SELECT * FROM pump_state WHERE id=1").fetchone()
    today = date.today().isoformat()
    if row["usage_date"] != today:
        db.execute("UPDATE pump_state SET used_minutes_today=0, usage_date=? WHERE id=1", (today,))

async def auto_stop_watcher():
    while True:
        try:
            state = read_pump()
            if state["is_on"] and state["end_time"] and time.time() >= state["end_time"]:
                await stop_pump("timer")
        except Exception:
            pass
        await asyncio.sleep(1)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    start_mqtt()
    task = asyncio.create_task(auto_stop_watcher())
    yield
    task.cancel()
    stop_mqtt()

app = FastAPI(title="ORBITERRA Smart Farming API", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict this to your deployed frontend domain before production.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

class SensorInput(BaseModel):
    soil_moisture: float = Field(ge=0, le=100)
    air_temperature: Optional[float] = Field(default=None, ge=-20, le=70)
    air_humidity: Optional[float] = Field(default=None, ge=0, le=100)
    soil_temperature: Optional[float] = Field(default=None, ge=-10, le=70)
    rainfall_mm: float = Field(default=0, ge=0, le=1000)

class FarmUpdate(BaseModel):
    farmer_name: Optional[str] = Field(default=None, max_length=100)
    village: Optional[str] = Field(default=None, max_length=100)
    district: Optional[str] = Field(default=None, max_length=100)
    area_acres: Optional[float] = Field(default=None, gt=0, le=100000)
    crop: Optional[str] = Field(default=None, max_length=100)
    crop_age_days: Optional[int] = Field(default=None, ge=0, le=5000)
    soil_type: Optional[str] = Field(default=None, max_length=100)
    terrain: Optional[str] = Field(default=None, max_length=100)

class IrrigationStart(BaseModel):
    duration_minutes: int = Field(ge=1, le=60)

def irrigation_advice(moisture, rainfall):
    # Demonstration thresholds only; calibrate for crop, soil, sensor depth and local agronomy.
    if rainfall >= 5:
        return "RAIN_RECENT", "Recent rainfall detected; re-check soil before irrigation."
    if moisture < 30:
        return "WATER_NEEDED", "Soil moisture is low. Verify the field and irrigation line before watering."
    if moisture < 40:
        return "MONITOR", "Moisture is approaching the lower range. Monitor the next reading."
    return "NO_WATERING", "Current sample moisture is adequate; irrigation is not recommended by this demo rule."

async def stop_pump(reason="manual"):
    state = read_pump()
    if not state["is_on"]:
        return {"is_on": False, "message": "Pump is already OFF."}
    await set_physical_relay(False)
    end = time.time()
    elapsed = max(0, (end - (state["started_at"] or end)) / 60)
    water = round(elapsed * 150, 1)  # Demo flow rate: 150 L/min. Replace with measured flow.
    with connect() as db:
        db.execute(
            "UPDATE pump_state SET is_on=0, started_at=NULL, end_time=NULL, duration_minutes=0 WHERE id=1"
        )
        db.execute(
            """UPDATE irrigation SET ended_at=?, status='COMPLETED', water_litres=?, stop_reason=?
               WHERE id=(SELECT MAX(id) FROM irrigation WHERE status='RUNNING')""",
            (now_iso(), water, reason)
        )
    return {"is_on": False, "message": "Pump stopped.", "stop_reason": reason, "estimated_water_litres": water}

@app.get("/")
def frontend():
    return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/health")
def health():
    return {
        "status": "ok", "service": "ORBITERRA API",
        "hardware_mode": "enabled" if HARDWARE_ENABLED else "simulation",
        "mqtt_enabled": MQTT_ENABLED, "mqtt_connected": mqtt_connected,
        "ai_service": "mqtt-integrated" if MQTT_ENABLED else "disabled",
    }

@app.get("/api/security/latest-recommendation")
def security_recommendation():
    return {"available": latest_ai_recommendation is not None,
            "recommendation": latest_ai_recommendation}

@app.get("/api/farm")
def get_farm():
    with connect() as db:
        return dict(db.execute("SELECT * FROM farm WHERE id=1").fetchone())

@app.put("/api/farm")
def update_farm(payload: FarmUpdate):
    values = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if not values:
        raise HTTPException(400, "No farm fields supplied.")
    query = ", ".join(f"{key}=?" for key in values)
    with connect() as db:
        db.execute(f"UPDATE farm SET {query} WHERE id=1", list(values.values()))
        return dict(db.execute("SELECT * FROM farm WHERE id=1").fetchone())

@app.get("/api/sensors/latest")
def get_latest_sensor():
    reading = latest_sensor()
    if not reading:
        raise HTTPException(404, "No sensor readings found.")
    return reading

@app.post("/api/sensors/ingest")
def ingest_sensor(payload: SensorInput, x_sensor_key: str = Header(default="")):
    if x_sensor_key != SENSOR_API_KEY:
        raise HTTPException(401, "Invalid sensor API key.")
    with connect() as db:
        cur = db.execute(
            """INSERT INTO sensor_readings
            (soil_moisture, air_temperature, air_humidity, soil_temperature, rainfall_mm, created_at)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (payload.soil_moisture, payload.air_temperature, payload.air_humidity,
             payload.soil_temperature, payload.rainfall_mm, now_iso())
        )
        reading = db.execute("SELECT * FROM sensor_readings WHERE id=?", (cur.lastrowid,)).fetchone()
        result = dict(reading)
    result["mqtt_published"] = publish_sensor_to_ai(result)
    return result

@app.get("/api/irrigation/status")
def irrigation_status():
    state = read_pump()
    remaining = max(0, int(state["end_time"] - time.time())) if state["is_on"] and state["end_time"] else 0
    return {
        "is_on": bool(state["is_on"]),
        "remaining_seconds": remaining,
        "duration_minutes": state["duration_minutes"],
        "used_minutes_today": round(state["used_minutes_today"], 1),
        "daily_limit_minutes": MAX_DAILY_MINUTES,
        "hardware_mode": "enabled" if HARDWARE_ENABLED else "simulation"
    }

@app.post("/api/irrigation/start")
async def start_irrigation(payload: IrrigationStart):
    state = read_pump()
    if state["is_on"]:
        raise HTTPException(409, "Pump is already running.")
    with connect() as db:
        normalize_daily_usage(db)
        state = db.execute("SELECT * FROM pump_state WHERE id=1").fetchone()
        used = float(state["used_minutes_today"])
        if used + payload.duration_minutes > MAX_DAILY_MINUTES:
            raise HTTPException(400, f"Daily safe limit of {MAX_DAILY_MINUTES} minutes would be exceeded.")
    # In real hardware mode, only issue ON after all server-side checks pass.
    await set_physical_relay(True)
    started = time.time()
    end_time = started + payload.duration_minutes * 60
    with connect() as db:
        db.execute(
            """UPDATE pump_state SET is_on=1, started_at=?, end_time=?, duration_minutes=?,
               used_minutes_today=used_minutes_today+? WHERE id=1""",
            (started, end_time, payload.duration_minutes, payload.duration_minutes)
        )
        db.execute(
            """INSERT INTO irrigation (started_at, duration_minutes, status)
               VALUES (?, ?, 'RUNNING')""",
            (now_iso(), payload.duration_minutes)
        )
    return irrigation_status()

@app.post("/api/irrigation/stop")
async def manual_stop():
    return await stop_pump("manual")

@app.get("/api/irrigation/history")
def irrigation_history(limit: int = 20):
    limit = max(1, min(limit, 100))
    with connect() as db:
        rows = db.execute(
            "SELECT * FROM irrigation ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

@app.get("/api/reports/summary")
def report_summary():
    today = date.today().isoformat()
    with connect() as db:
        rows = db.execute(
            """SELECT COUNT(*) AS sessions, COALESCE(SUM(water_litres),0) AS water_litres,
               COALESCE(SUM(duration_minutes),0) AS total_minutes
               FROM irrigation WHERE substr(started_at,1,10)=?""", (today,)
        ).fetchone()
        weekly = db.execute(
            """SELECT substr(started_at,1,10) AS day, SUM(water_litres) AS litres
               FROM irrigation WHERE started_at >= datetime('now','-6 days')
               GROUP BY substr(started_at,1,10) ORDER BY day"""
        ).fetchall()
        return {"today": dict(rows), "daily_water_usage": [dict(r) for r in weekly],
                "note": "Water volume is estimated from the configured demo flow rate unless a calibrated flow meter is connected."}

@app.get("/api/dashboard")
def dashboard():
    sensor = latest_sensor()
    farm = get_farm()
    pump = irrigation_status()
    code, advice = irrigation_advice(sensor["soil_moisture"], sensor["rainfall_mm"])
    return {
        "farm": farm,
        "sensor": sensor,
        "pump": pump,
        "irrigation_advice": {"code": code, "message": advice},
        "generated_at": now_iso()
    }

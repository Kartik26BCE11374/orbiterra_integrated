(() => {
  const API = "";
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];
  const toast = (message) => {
    const el = $("#toast");
    if (!el) return;
    el.textContent = message;
    el.classList.remove("opacity-0");
    el.classList.add("opacity-100");
    clearTimeout(window.orbitToastTimer);
    window.orbitToastTimer = setTimeout(() => {
      el.classList.remove("opacity-100");
      el.classList.add("opacity-0");
    }, 3500);
  };
  const fmt = (n, digits = 0) => n == null ? "—" : Number(n).toFixed(digits);
  const setText = (selector, value) => {
    const el = $(selector);
    if (el && value != null) el.textContent = value;
  };

  async function request(path, options = {}) {
    const response = await fetch(API + path, {
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || `Request failed (${response.status})`);
    return data;
  }

  function updateDashboard(data) {
    const s = data.sensor || {};
    const p = data.pump || {};
    const advice = data.irrigation_advice || {};

    // Dashboard sensor values (the original page contains sample values).
    const homeStats = $$("#home .grid.grid-cols-1.sm\\:grid-cols-3 .agri-card");
    if (homeStats[0]) homeStats[0].querySelector(".font-head").textContent = `${fmt(s.air_temperature, 1)}°C`;
    if (homeStats[1]) homeStats[1].querySelector(".font-head").textContent = `${fmt(s.air_humidity, 1)}%`;

    const gauge = $("#home circle[stroke-dasharray='314.16']");
    if (gauge) {
      const moisture = Math.max(0, Math.min(100, Number(s.soil_moisture || 0)));
      gauge.setAttribute("stroke-dashoffset", String(314.16 * (1 - moisture / 100)));
    }
    const gaugeLabel = $("#home .relative.w-36 .font-head");
    if (gaugeLabel) gaugeLabel.textContent = `${fmt(s.soil_moisture)}%`;

    const soilSection = $("#soil");
    if (soilSection) {
      const vals = soilSection.querySelectorAll(".font-head.font-extrabold");
      if (vals[0]) vals[0].textContent = `${fmt(s.soil_moisture)}%`;
      if (vals[1] && s.soil_temperature != null) vals[1].textContent = `${fmt(s.soil_temperature, 1)}°C`;
    }

    const weather = $("#weather");
    if (weather) {
      const vals = weather.querySelectorAll(".font-head.font-extrabold");
      if (vals[0] && s.air_temperature != null) vals[0].textContent = `${fmt(s.air_temperature, 1)}°C`;
    }

    $$(".pump-state-text").forEach(el => {
      el.textContent = p.is_on ? "ON" : "OFF";
    });
    $$(".pump-state-note").forEach(el => {
      el.textContent = p.is_on ? `${fmt(p.remaining_seconds / 60, 1)} min remaining` : "Not running";
    });
    setText("#used-mins", fmt(p.used_minutes_today, 1));
    const usedBar = $("#used-bar");
    if (usedBar) usedBar.style.width = `${Math.min(100, (p.used_minutes_today / p.daily_limit_minutes) * 100)}%`;

    const live = $("#live-pump-card");
    if (live) live.classList.toggle("hidden", !p.is_on);
    if (p.is_on) {
      setText("#countdown-display", `${String(Math.floor(p.remaining_seconds / 60)).padStart(2,"0")}:${String(p.remaining_seconds % 60).padStart(2,"0")}`);
      const progress = $("#session-progress-bar");
      if (progress) progress.style.width = `${Math.max(0, Math.min(100, p.remaining_seconds / (p.duration_minutes * 60) * 100))}%`;
    }
    $$("[data-start]").forEach(b => b.disabled = !!p.is_on);
    $$("[data-stop]").forEach(b => b.disabled = !p.is_on);

    // Replace the hero recommendation with backend-derived advice.
    const hero = $("#home .rounded-3xl.bg-gradient-to-br.from-forest-900");
    if (hero && advice.message) {
      const paragraph = hero.querySelector("p");
      if (paragraph) paragraph.textContent = advice.message;
      const heading = hero.querySelector("h2");
      if (heading) heading.textContent = advice.code === "WATER_NEEDED" ? "Check irrigation now" :
        advice.code === "MONITOR" ? "Monitor soil moisture" :
        advice.code === "RAIN_RECENT" ? "Rain detected — wait and re-check" : "No watering indicated";
    }
  }

  async function refresh() {
    try {
      const data = await request("/api/dashboard");
      updateDashboard(data);
      window.orbitBackendConnected = true;
    } catch (err) {
      window.orbitBackendConnected = false;
      console.warn("ORBITERRA backend unavailable:", err.message);
    }
  }

  // Capture phase prevents the original browser-only pump demo handlers from firing.
  document.addEventListener("click", async (event) => {
    const start = event.target.closest("[data-start]");
    const stop = event.target.closest("[data-stop]");
    if (!start && !stop) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    try {
      if (start) {
        const selected = $(".selected-mins-label")?.textContent || "30";
        const duration = Number.parseInt(selected, 10);
        await request("/api/irrigation/start", {
          method: "POST",
          body: JSON.stringify({ duration_minutes: Number.isFinite(duration) ? duration : 30 })
        });
        toast(`Pump start command accepted (${duration} minutes).`);
      } else {
        await request("/api/irrigation/stop", { method: "POST", body: "{}" });
        toast("Pump stop command accepted.");
      }
      await refresh();
    } catch (err) {
      toast(err.message);
    }
  }, true);

  refresh();
  setInterval(refresh, 5000);
})();

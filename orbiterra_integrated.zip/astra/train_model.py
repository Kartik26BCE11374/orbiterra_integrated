import pandas as pd, numpy as np, pickle
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_absolute_error, r2_score, accuracy_score
from sklearn.preprocessing import LabelEncoder

df = pd.read_csv(BASE_DIR / 'training_data_real.csv')
print(f"Training on {len(df):,} rows from {df['farm_id'].nunique():,} farms\n")

# Encode categoricals
encoders = {}
for col in ['soil_type', 'crop_type', 'region', 'season']:
    le = LabelEncoder()
    df[col + '_enc'] = le.fit_transform(df[col])
    encoders[col] = le

features = [
    'sensor_moisture', 'temperature', 'eto', 'rain_mm',
    'days_since_irrigation', 'cloud_cover', 'rainfall_anomaly_pct',
    'soil_type_enc', 'crop_type_enc', 'region_enc', 'season_enc',
]
X = df[features].values
y_reg = df['optimal_duration_min'].values
y_clf = df['irrigation_needed'].values
groups = df['farm_id'].values

# Hold out entire farms — prevents leakage
gkf = GroupKFold(n_splits=5)
tr, te = next(iter(gkf.split(X, y_reg, groups)))
print(f"Train: {len(tr):,} rows  |  Test: {len(te):,} rows (held-out farms)\n")

# ---------- FAO-56 baseline (default loam, 75% efficiency) ----------
def fao56_baseline(Xb):
    moisture = Xb[:, 0]  # sensor_moisture
    dr = np.maximum(0.0, (30.0 - moisture) / 100.0 * 400.0)
    return np.minimum(dr / 8.0 * 60.0 * 1.33, 120.0)

base_pred = fao56_baseline(X[te])
base_mae = mean_absolute_error(y_reg[te], base_pred)

# ---------- ML regressor ----------
reg = RandomForestRegressor(n_estimators=200, max_depth=14, random_state=42, n_jobs=-1)
reg.fit(X[tr], y_reg[tr])
ml_pred = reg.predict(X[te])
ml_mae = mean_absolute_error(y_reg[te], ml_pred)
ml_r2  = r2_score(y_reg[te], ml_pred)

# ---------- ML classifier ----------
clf = RandomForestClassifier(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
clf.fit(X[tr], y_clf[tr])
clf_acc = accuracy_score(y_clf[te], clf.predict(X[te]))

print("=" * 60)
print(f"FAO-56 baseline MAE:      {base_mae:6.2f} min")
print(f"ML regressor      MAE:    {ml_mae:6.2f} min   R² = {ml_r2:.3f}")
print(f"Improvement vs baseline:  {(base_mae - ml_mae) / base_mae * 100:.1f}%")
print(f"Classifier accuracy:      {clf_acc*100:.1f}%")
print("=" * 60)

# ---------- Per-region breakdown (this is the pitch table) ----------
print("\nPer-region MAE on held-out farms:")
print(f"  {'Region':<25} {'FAO-56':>8} {'ML':>8} {'Improve':>9}")
print(f"  {'-'*25} {'-'*8} {'-'*8} {'-'*9}")
test_regions = df.iloc[te]['region'].values
for region in sorted(df['region'].unique()):
    mask = test_regions == region
    if mask.sum() < 10:
        continue
    r_base = mean_absolute_error(y_reg[te][mask], base_pred[mask])
    r_ml   = mean_absolute_error(y_reg[te][mask], ml_pred[mask])
    pct    = (r_base - r_ml) / r_base * 100 if r_base > 0 else 0
    print(f"  {region:<25} {r_base:>7.2f}  {r_ml:>7.2f}  {pct:>+7.1f}%")

# ---------- Feature importance ----------
print("\nTop features (regressor):")
for name, imp in sorted(zip(features, reg.feature_importances_), key=lambda x: -x[1])[:10]:
    bar = '█' * int(imp * 50)
    print(f"  {name:<24} {imp:.3f}  {bar}")

# ---------- Save ----------
pickle.dump({
    'regressor': reg, 'classifier': clf,
    'features': features, 'encoders': encoders,
    'metrics': {'base_mae': float(base_mae), 'ml_mae': float(ml_mae),
                'r2': float(ml_r2), 'clf_acc': float(clf_acc)},
}, open(BASE_DIR / 'model.pkl', 'wb'))
print(f"\n✓ Saved model.pkl")

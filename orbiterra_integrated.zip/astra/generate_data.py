import pandas as pd, numpy as np, os, glob
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

np.random.seed(42)
SEASON_DAYS = {'Winter': 90, 'Pre-monsoon': 92, 'Southwest_Monsoon': 122, 'Post_monsoon': 61}
SEASON_MAP  = {'December-February': 'Winter', 'March-May': 'Pre-monsoon',
               'June-September': 'Southwest_Monsoon', 'October-November': 'Post_monsoon'}
KC = {'Winter': 0.6, 'Pre-monsoon': 0.8, 'Southwest_Monsoon': 1.05, 'Post_monsoon': 0.9}

REQUIRED_COLS = {'year', 'season', 'seasonal_rainfall_mm', 'mean_temperature_c'}

rows = []
loaded = []
skipped = []
for csv in sorted(glob.glob(str(BASE_DIR / 'data' / 'climate' / '*.csv'))):
    name = os.path.basename(csv).replace('.csv', '')
    try:
        df = pd.read_csv(csv, encoding='utf-8-sig', nrows=1)
        df.columns = df.columns.str.strip().str.lower()
    except Exception as e:
        skipped.append((name, f"read error: {e}"))
        continue

    if not REQUIRED_COLS.issubset(df.columns):
        skipped.append((name, f"missing columns: {sorted(REQUIRED_COLS - set(df.columns))}"))
        continue

    df = pd.read_csv(csv, encoding='utf-8-sig')
    df.columns = df.columns.str.strip().str.lower()
    loaded.append(name)
    print(f"Loading {name}: {len(df)} rows")

    if 'season' not in df.columns and 'season_months' in df.columns:
        df['season'] = df['season_months'].map(SEASON_MAP)

    for _, r in df.iterrows():
        season = SEASON_MAP.get(str(r['season']), str(r['season']))
        ndays = SEASON_DAYS.get(season, 90)
        region = r.get('terrain_id', name)
        year = int(r['year'])

        t_mean = r['mean_temperature_c']
        cloud  = r['mean_cloud_cover_pct']
        rain_total = r['seasonal_rainfall_mm']
        rain_anomaly = r['rainfall_anomaly_pct']

        solar = max(5.0, 28.0 * (1.0 - 0.7 * cloud / 100.0))
        eto_region = 0.0023 * (t_mean + 17.8) * np.sqrt(max(1, t_mean)) * (solar / 2.45)
        eto_region = float(max(1.5, min(9.0, eto_region)))

        if rain_total > 0:
            n_rain_days = max(3, int(ndays * 0.25))
            weights = np.random.dirichlet(np.ones(n_rain_days))
            daily_rain = np.zeros(ndays)
            rain_idx = np.random.choice(ndays, size=n_rain_days, replace=False)
            daily_rain[rain_idx] = weights * rain_total
        else:
            daily_rain = np.zeros(ndays)

        for farm_idx in range(4):
            soil_type = np.random.choice(['sandy', 'loam', 'clay'], p=[0.3, 0.5, 0.2])
            fc = {'sandy': 20.0, 'loam': 30.0, 'clay': 38.0}[soil_type]
            wp = {'sandy': 8.0,  'loam': 14.0, 'clay': 20.0}[soil_type]
            eff = np.random.uniform(0.70, 0.90)
            du  = np.random.uniform(0.80, 0.95)
            crop = np.random.choice(['wheat', 'rice', 'maize'])
            kc = KC.get(season, 0.9) * np.random.uniform(0.9, 1.1)
            moisture = np.random.uniform(wp + 3, fc - 2)
            days_since = np.random.randint(0, 5)

            for day in range(ndays):
                t = float(t_mean + np.random.normal(0, 3))
                eto = float(max(1.5, min(9.0, eto_region + np.random.normal(0, 0.5))))
                rain = float(daily_rain[day])

                root = 400.0
                dr_mm = (fc - moisture) / 100.0 * root
                dr_mm += kc * eto - rain
                dr_mm = max(0.0, min(dr_mm, (fc - wp) / 100.0 * root))
                moisture = fc - (dr_mm / root * 100.0)

                mad = (fc + wp) / 2
                if moisture < mad:
                    net_mm = (fc - moisture) / 100.0 * root
                    gross_mm = net_mm / (eff * du)
                    duration_min = min(gross_mm / 8.0 * 60.0, 120.0)
                    irrigated = 1
                    days_since = 0
                else:
                    duration_min = 0.0
                    irrigated = 0
                    days_since += 1

                sensor_moisture = float(np.clip(moisture + np.random.normal(0, 1.5), 0, 100))

                rows.append({
                    'region': region, 'season': season, 'year': year,
                    'farm_id': f"{region}_{year}_{season}_{farm_idx}",
                    'day': day,
                    'soil_type': soil_type, 'crop_type': crop,
                    'sensor_moisture': round(sensor_moisture, 2),
                    'temperature': round(t, 1),
                    'cloud_cover': round(float(cloud), 1),
                    'rainfall_anomaly_pct': round(float(rain_anomaly), 1),
                    'eto': round(eto, 2),
                    'rain_mm': round(rain, 2),
                    'days_since_irrigation': days_since,
                    'optimal_duration_min': round(duration_min, 1),
                    'irrigation_needed': irrigated,
                })

print(f"\n=== Loaded {len(loaded)} regional files ===")
for n in loaded:
    print(f"  ✓ {n}")

if skipped:
    print(f"\n=== Skipped {len(skipped)} non-regional files ===")
    for n, reason in skipped:
        print(f"  ✗ {n}: {reason}")

if not rows:
    raise SystemExit("\nNo data generated.")

df = pd.DataFrame(rows)
df.to_csv(BASE_DIR / 'training_data_real.csv', index=False)
print(f"\nGenerated {len(df):,} rows")
print(f"Regions: {df['region'].nunique()}, Years: {df['year'].nunique()}, "
      f"Seasons: {df['season'].nunique()}, Farms: {df['farm_id'].nunique():,}")
print(f"Irrigation events: {df['irrigation_needed'].sum():,} "
      f"({df['irrigation_needed'].mean()*100:.1f}%)")
print("\nAvg irrigation duration per region (min):")
print(df.groupby('region')['optimal_duration_min'].agg(['mean','count']).round(2))

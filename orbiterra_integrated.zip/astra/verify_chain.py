"""Verify the ASTRA append-only audit hash chain."""
import hashlib
import json
import os
from pathlib import Path

log_path = Path(os.getenv("ASTRA_AUDIT_LOG", Path(__file__).resolve().parent / "logs" / "astra_ai.jsonl"))
if not log_path.exists():
    raise SystemExit(f"Audit log not found: {log_path}")

previous = "0" * 64
ok = True
checked = 0
with log_path.open(encoding="utf-8") as stream:
    for line_number, line in enumerate(stream, 1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
            head = record.pop("head")
            body = json.dumps(record, sort_keys=True, separators=(",", ":"))
            calculated = hashlib.sha256(body.encode()).hexdigest()
            if record.get("prev") != previous or calculated != head:
                print(f"CHAIN ERROR at line {line_number} (seq={record.get('seq')})")
                ok = False
            previous = head
            checked += 1
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            print(f"INVALID RECORD at line {line_number}: {exc}")
            ok = False
print(f"Checked {checked} records.")
print("CHAIN OK" if ok else "CHAIN BROKEN")
if not ok:
    raise SystemExit(1)

"""ASTRA cybersecurity and irrigation-decision service.

Consumes device telemetry over mutually authenticated MQTT/TLS, detects anomalous
sensor behaviour, publishes HMAC-signed recommendations, and maintains a
tamper-evident SHA-256 audit chain.
"""
import hashlib
import hmac
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import paho.mqtt.client as mqtt
from sklearn.ensemble import IsolationForest

BASE_DIR = Path(__file__).resolve().parent
LOG_PATH = Path(os.getenv("ASTRA_AUDIT_LOG", BASE_DIR / "logs" / "astra_ai.jsonl"))
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("astra.ai")

MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_PORT = int(os.getenv("MQTT_PORT", "8883"))
MQTT_CA = os.getenv("MQTT_CA", str(BASE_DIR / "certs" / "ca.crt"))
MQTT_CERT = os.getenv("MQTT_CERT", str(BASE_DIR / "certs" / "astra-ai.crt"))
MQTT_KEY = os.getenv("MQTT_KEY", str(BASE_DIR / "certs" / "astra-ai.key"))
MQTT_CLIENT_ID = os.getenv("MQTT_CLIENT_ID", "astra-ai")
HMAC_KEY = os.getenv("ASTRA_HMAC_KEY", "development-only-change-this-key").encode()
if len(HMAC_KEY) < 32:
    raise RuntimeError("ASTRA_HMAC_KEY must contain at least 32 characters.")

class Chain:
    """Append-only hash chain; resumes from the last record after restart."""
    def __init__(self, path):
        self.path = Path(path)
        self.prev = "0" * 64
        self.seq = 0
        if self.path.exists():
            previous = "0" * 64
            last_record = None
            try:
                for line in self.path.read_text(encoding="utf-8").splitlines():
                    if not line.strip():
                        continue
                    record = json.loads(line)
                    head = record.pop("head")
                    canonical = json.dumps(record, sort_keys=True, separators=(",", ":"))
                    calculated = hashlib.sha256(canonical.encode()).hexdigest()
                    if record.get("prev") != previous or not hmac.compare_digest(calculated, head):
                        raise RuntimeError("Audit hash chain is broken; refusing to append.")
                    previous = head
                    last_record = (record, head)
                if last_record is not None:
                    self.seq = int(last_record[0]["seq"])
                    self.prev = last_record[1]
            except (ValueError, KeyError, json.JSONDecodeError) as exc:
                raise RuntimeError("Audit log is invalid; refusing to append.") from exc
        self.boot = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    def add(self, event):
        self.seq += 1
        record = {"boot": self.boot, "seq": self.seq, "prev": self.prev, **event}
        raw = json.dumps(record, sort_keys=True, separators=(",", ":"))
        record["head"] = hashlib.sha256(raw.encode()).hexdigest()
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, sort_keys=True) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        self.prev = record["head"]
        return record

chain = Chain(LOG_PATH)

# Demo detector baseline. Replace with a validated, farm-specific model before deployment.
rng = np.random.default_rng(42)
normal_samples = rng.normal(loc=[28, 3.5], scale=[4, 0.5], size=(500, 2))
anomaly_model = IsolationForest(n_estimators=100, contamination=0.05,
                                random_state=42).fit(normal_samples)

KC = {"initial": 0.4, "dev": 0.8, "mid": 1.05, "late": 0.9}
FIELD_CAPACITY, ROOT_DEPTH, FLOW_MM_HR = 32.0, 400.0, 8.0

def sign_command(command):
    body = {key: command[key] for key in ("cmd", "duration_min", "seq", "device")}
    raw = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    return hmac.new(HMAC_KEY, raw, hashlib.sha256).hexdigest()

def fao56(moisture, kc, rain_mm, eto):
    depletion = max(0.0, (FIELD_CAPACITY - moisture) / 100.0 * ROOT_DEPTH)
    crop_use = kc * eto
    net = max(0.0, depletion - rain_mm - crop_use)
    return round(net * 60.0 / FLOW_MM_HR, 1), round(depletion, 1)

def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        log.info("Connected to MQTT broker using verified mutual TLS")
        client.subscribe("devices/+/sensors", qos=1)
    else:
        log.error("MQTT connection rejected: %s", reason_code)

def on_message(client, userdata, message):
    try:
        data = json.loads(message.payload.decode("utf-8"))
        device = message.topic.split("/")[1]
        moisture = float(data["moisture"])
        current = float(data.get("current", 0.0))
        eto = float(data.get("eto", 4.0))
        rain = float(data.get("rain_mm", 0.0))
        if not (0 <= moisture <= 100 and 0 <= current <= 100 and 0 <= eto <= 20 and 0 <= rain <= 1000):
            raise ValueError("Telemetry value outside accepted bounds")
        stage = str(data.get("stage", "mid"))
        kc = KC.get(stage, KC["mid"])

        sample = np.array([[moisture, current]])
        score = float(anomaly_model.decision_function(sample)[0])
        if_flag = bool(anomaly_model.predict(sample)[0] == -1)
        z_flag = abs((moisture - 28.0) / 4.0) > 3
        tamper = bool(if_flag and z_flag)

        fao_minutes, depletion = fao56(moisture, kc, rain, eto)
        ml_minutes = round(fao_minutes * (0.9 if moisture > 25 else 1.1), 1)
        if tamper:
            decision, duration, reason = "FALLBACK", 0.0, "sensor_anomaly_requires_review"
        elif ml_minutes > fao_minutes * 1.5 or fao_minutes == 0.0:
            decision, duration, reason = "FAO56", fao_minutes, "ml_not_better"
        else:
            decision, duration, reason = "ML", ml_minutes, "ml_refined"

        # AI service sends recommendations only. Hardware actuation remains in the
        # separately guarded backend/controller; anomalous readings fail closed.
        command = {
            "cmd": "irrigation_recommendation",
            "duration_min": duration,
            "seq": chain.seq + 1,
            "device": device,
            "decision": decision,
            "reason": reason,
        }
        command["sig"] = sign_command(command)
        client.publish(f"devices/{device}/commands", json.dumps(command), qos=1)

        event = {
            "ts": datetime.now(timezone.utc).isoformat(), "device": device,
            "decision": decision, "duration_min": duration,
            "fao56_min": fao_minutes, "ml_min": ml_minutes,
            "depletion_mm": depletion, "anomaly_score": round(score, 4),
            "if_flag": if_flag, "z_flag": z_flag, "tamper": tamper,
            "moisture": moisture, "reason": reason,
        }
        log.info("Processed telemetry: %s", json.dumps(chain.add(event)))
    except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        log.warning("Rejected malformed or out-of-range telemetry on %s: %s",
                    message.topic, exc)
        chain.add({"ts": datetime.now(timezone.utc).isoformat(),
                   "topic": message.topic, "event": "telemetry_rejected",
                   "reason": str(exc)})

def build_client():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=MQTT_CLIENT_ID)
    client.tls_set(ca_certs=MQTT_CA, certfile=MQTT_CERT, keyfile=MQTT_KEY)
    client.tls_insecure_set(False)
    client.on_connect = on_connect
    client.on_message = on_message
    client.reconnect_delay_set(min_delay=1, max_delay=30)
    return client

if __name__ == "__main__":
    client = build_client()
    log.info("Starting ASTRA security/decision service against %s:%s", MQTT_HOST, MQTT_PORT)
    while True:
        try:
            client.connect(MQTT_HOST, MQTT_PORT, keepalive=60)
            break
        except OSError as exc:
            log.warning("MQTT broker not ready (%s); retrying in 3 seconds", exc)
            time.sleep(3)
    client.loop_forever()

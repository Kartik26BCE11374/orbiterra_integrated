"""Optional MQTT sensor/pump simulator for local development only."""
import json
import os
import random
import time
import paho.mqtt.client as mqtt

HOST = os.getenv("MQTT_HOST", "localhost")
PORT = int(os.getenv("MQTT_PORT", "8883"))
BASE = os.path.dirname(os.path.abspath(__file__))

def on_connect(client, userdata, flags, reason_code, properties):
    print("DEVICE connected:", reason_code)
    client.subscribe("devices/pump-001/commands", qos=1)

def on_message(client, userdata, msg):
    print("SIGNED AI RECOMMENDATION RECEIVED:", msg.payload.decode())

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="pump-001-simulator")
client.tls_set(ca_certs=os.getenv("MQTT_CA", os.path.join(BASE, "certs", "ca.crt")),
               certfile=os.getenv("MQTT_CERT", os.path.join(BASE, "certs", "pump-001.crt")),
               keyfile=os.getenv("MQTT_KEY", os.path.join(BASE, "certs", "pump-001.key")))
client.tls_insecure_set(False)
client.on_connect = on_connect
client.on_message = on_message
client.reconnect_delay_set(min_delay=1, max_delay=30)

while True:
    try:
        client.connect(HOST, PORT, 60)
        break
    except OSError as exc:
        print("MQTT broker not ready:", exc)
        time.sleep(3)
client.loop_start()
try:
    while True:
        sample = {
            "moisture": round(random.uniform(18, 32), 1),
            "current": round(random.uniform(3.0, 4.0), 2),
            "eto": 4.0, "rain_mm": 0.0, "stage": "mid"
        }
        client.publish("devices/pump-001/sensors", json.dumps(sample), qos=1)
        print("SENT:", sample)
        time.sleep(5)
except KeyboardInterrupt:
    pass
finally:
    client.loop_stop()
    client.disconnect()
